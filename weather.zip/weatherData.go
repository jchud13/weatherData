package main

type WeatherData struct {
    ID   int
    City  string
    Humidty   string
    Temp float64
	Temp_max float64
	Temo_min float64
}